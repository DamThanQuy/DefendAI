﻿export const apiKey = "SECRET-123";
console.log("debug");
